Build Week 1
Rev 0: prima emissione

Rev 1:
- modifiche generali dell'HTML per migliorare il posizionamento degli elementi
- modifiche dello style per migliorare elementi del DOM
- un po' di ordine in JS.